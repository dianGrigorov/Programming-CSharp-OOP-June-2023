﻿namespace BorderControl.Engine.Interfaces;

public interface IEngine
{
    void Start();
}
