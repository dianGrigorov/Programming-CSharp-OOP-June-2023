﻿namespace Telephony.Models.Interfaces;

public interface ICallable
{
    string Calling(string phoneNUmber);
}
