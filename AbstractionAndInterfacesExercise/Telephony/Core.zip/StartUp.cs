﻿using Telephony.Core;
using Telephony.Models;
using Telephony.Models.Interfaces;

Engine engine = new();

engine.Start();