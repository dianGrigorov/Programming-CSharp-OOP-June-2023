﻿using CollectionHierarchy.Core;
using CollectionHierarchy.Core.Interfaces;

IEngine eng = new Engine();
eng.Run();