﻿
namespace BirthdaySelebrations.Models.Interfaces;

public interface INameable
{
    string Name { get; }
}
