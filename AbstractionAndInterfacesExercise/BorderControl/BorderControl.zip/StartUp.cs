﻿using BorderControl.Engine;

Engine engine = new Engine();
engine.Start();